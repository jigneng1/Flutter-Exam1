package com.example.textform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
